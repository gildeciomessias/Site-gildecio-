import Header from "@/components/Header";
import HeroSection from "@/components/HeroSection";
import ServicesDetailSection from "@/components/ServicesDetailSection";
import ComparisonSection from "@/components/ComparisonSection";
import MapSection from "@/components/MapSection";
import FAQSection from "@/components/FAQSection";
import Footer from "@/components/Footer";

const Index = () => {
  return (
    <div className="min-h-screen">
      <Header />
      <main>
        <HeroSection />
        <ServicesDetailSection />
        <ComparisonSection />
        <MapSection />
        <FAQSection />
      </main>
      <Footer />
    </div>
  );
};

export default Index;
