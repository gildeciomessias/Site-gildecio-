import { useParams } from "react-router-dom";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

const posts = [
  {
    slug: "marketing-digital-para-pequenas-empresas",
    title: "Marketing Digital para Pequenas Empresas: Guia Completo 2024",
    content: `
      <p>Conteúdo completo do post aqui...</p>
    `,
    date: "2024-03-15",
    author: "Gildecio Pires",
    image:
      "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&h=400&fit=crop",
  },
  {
    slug: "como-criar-site-profissional",
    title: "Como Criar um Site Profissional que Converte Visitantes em Clientes",
    content: `
      <p>Conteúdo completo do post aqui...</p>
    `,
    date: "2024-03-10",
    author: "Gildecio Pires",
    image:
      "https://images.unsplash.com/photo-1467232004584-a241de8bcf5d?w=800&h=400&fit=crop",
  },
];

export default function BlogPost() {
  const { slug } = useParams();
  const post = posts.find((p) => p.slug === slug);

  if (!post) {
    return <div>Post not found.</div>;
  }

  return (
    <div className="min-h-screen bg-white">
      <Header />

      <section className="pt-32 pb-16 container mx-auto px-4">
        <img src={post.image} className="w-full rounded-xl mb-10" />

        <h1 className="text-4xl font-bold mb-4">{post.title}</h1>
        <p className="text-muted-foreground mb-10">
          {new Date(post.date).toLocaleDateString()} — {post.author}
        </p>

        <article
          className="prose prose-lg"
          dangerouslySetInnerHTML={{ __html: post.content }}
        />
      </section>

      <Footer />
    </div>
  );
}