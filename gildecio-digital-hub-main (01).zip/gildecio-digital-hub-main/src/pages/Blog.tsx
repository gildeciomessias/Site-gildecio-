// src/pages/Blog.tsx
import { Link } from "react-router-dom";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Calendar, User, ArrowRight } from "lucide-react";
import { posts } from "../data/posts"; // import relativo que costuma funcionar

const Blog = () => {
  return (
    <div className="min-h-screen bg-slate-light">
      <Header />
      <main>
        <section className="pt-32 pb-16 bg-gradient-to-br from-teal-deep via-teal-medium to-turquoise relative overflow-hidden">
          <div className="container mx-auto px-4 relative z-10 text-center animate-fade-up">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white">
              Digital Marketing Insights
            </h1>
            <p className="text-xl text-white/90">
              Tips, strategies and news about digital marketing, web design and business growth
            </p>
          </div>
        </section>

        <section className="py-20">
          <div className="container mx-auto px-4">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {posts.map((post, index) => (
                <Card
                  key={post.slug}
                  className="group hover:shadow-xl transition-all duration-300 hover:-translate-y-2 border-2 border-turquoise/20 hover:border-turquoise bg-white overflow-hidden animate-fade-up"
                  style={{ animationDelay: ${index * 0.1}s }}
                >
                  <div className="relative h-48 overflow-hidden">
                    <img
                      src={post.image}
                      alt={post.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                    />
                    <div className="absolute top-4 left-4">
                      <span className="bg-gold text-white px-3 py-1 rounded-full text-sm font-semibold">
                        {post.category}
                      </span>
                    </div>
                  </div>
                  <CardHeader>
                    <CardTitle className="text-xl font-bold text-teal-deep group-hover:text-turquoise transition-colors line-clamp-2">
                      {post.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-muted-foreground line-clamp-3">{post.excerpt}</p>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Calendar className="w-4 h-4" />
                        <span>{new Date(post.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <User className="w-4 h-4" />
                        <span>{post.author}</span>
                      </div>
                    </div>
                    <Link
                      to={/blog/${post.slug}}
                      className="inline-flex items-center gap-2 text-turquoise font-semibold hover:text-gold transition-colors group/link"
                    >
                      Read More
                      <ArrowRight className="w-4 h-4 group-hover/link:translate-x-1 transition-transform" />
                    </Link>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default Blog;